//Haosong Chen
//SID: haosongc
package ds.edu.cryptoapp

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.google.gson.Gson
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import okhttp3.OkHttpClient
import okhttp3.Request

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            CryptoApp()
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CryptoApp() {
    // States for UI components
    var searchTerm by remember { mutableStateOf("") } // Holds the user input for cryptocurrency name
    var result by remember { mutableStateOf("Enter a cryptocurrency name") } // Holds the result or error message
    val coroutineScope = rememberCoroutineScope() // Coroutine scope for asynchronous operations

    // Build the UI
    Scaffold(
        topBar = {
            CenterAlignedTopAppBar(title = { Text("Crypto Price Checker") }) // Top App Bar
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            // 1. Input Field (OutlinedTextField): Allows the user to input cryptocurrency name
            OutlinedTextField(
                value = searchTerm,
                onValueChange = { searchTerm = it },
                label = { Text("Enter cryptocurrency") },
                modifier = Modifier.padding(16.dp)
            )

            // 2. Button: Fetches the cryptocurrency price from the server
            Button(
                onClick = {
                    coroutineScope.launch(Dispatchers.IO) {
                        result = fetchCryptoPrice(searchTerm) // Fetches the price or error message
                    }
                },
                modifier = Modifier.padding(16.dp)
            ) {
                Text("Get Price")
            }

            // 3. Display Result (Text): Shows the price of the cryptocurrency or an error message
            Text(
                text = result,
                modifier = Modifier.padding(16.dp),
                style = MaterialTheme.typography.bodyLarge
            )
        }
    }
}

/**
 * Fetches the price of the cryptocurrency from the backend server.
 * @param coin Name of the cryptocurrency
 * @return Price or error message
 */
fun fetchCryptoPrice(coin: String): String {
    val client = OkHttpClient()
    val url = "https://verbose-guide-rqwgpr6766phwqwq-8080.app.github.dev/crypto?coin=$coin" // Adjust URL as per deployment
    val request = Request.Builder().url(url).build()

    return try {
        val response = client.newCall(request).execute()
        if (response.isSuccessful) {
            val responseBody = response.body?.string()
            val gson = Gson()
            val jsonObject = gson.fromJson(responseBody, Map::class.java)
            jsonObject["message"]?.toString() ?: "Invalid response from server"
        } else {
            "Error: ${response.code}"
        }
    } catch (e: Exception) {
        "Error: ${e.message}"
    }
}